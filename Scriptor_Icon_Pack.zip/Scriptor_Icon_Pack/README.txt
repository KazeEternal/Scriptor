Scriptor Icon Pack
==================

Files
-----
Scriptor.ico
    Multi-resolution Windows application icon containing:
    16, 20, 24, 32, 40, 48, 64, 128, and 256 pixel icon sizes.

Scriptor_16x16.png through Scriptor_512x512.png
    Individual transparent PNG assets.

Scriptor_Master.png
    High-resolution transparent master artwork.

Visual Studio / C# usage
------------------------
For a typical .NET project, copy Scriptor.ico into the project, for example:

    Assets/Scriptor.ico

Then add this to the .csproj PropertyGroup:

    <ApplicationIcon>Assets\Scriptor.ico</ApplicationIcon>

For WinForms, you can also assign the form's Icon property to Scriptor.ico.

For WPF, set the Window Icon property, for example:

    Icon="Assets/Scriptor.ico"

The .ico should be used as the primary Windows executable icon because it
contains multiple resolutions for Explorer, shortcuts, title bars, and other
Windows shell surfaces.
